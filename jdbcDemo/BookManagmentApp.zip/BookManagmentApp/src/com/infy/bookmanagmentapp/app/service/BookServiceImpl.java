package com.infy.bookmanagmentapp.app.service;

import com.infy.bookmanagmentapp.app.dao.BookDaoI;
import com.infy.bookmanagmentapp.app.dao.BookDaoImpl;
import com.infy.bookmanagmentapp.app.model.Book;

public class BookServiceImpl implements BookServiceI{

	BookDaoI bdi=new BookDaoImpl();
	
	@Override
	public void addBook(Book b) {
	
		bdi.addBook(b);
		
	}
	@Override
	public void viewBooks() {
		
		bdi.viewBooks();
	}

}
