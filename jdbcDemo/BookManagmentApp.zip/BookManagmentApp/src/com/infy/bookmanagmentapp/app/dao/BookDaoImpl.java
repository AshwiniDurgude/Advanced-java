package com.infy.bookmanagmentapp.app.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.infy.bookmanagmentapp.app.model.Book;

public class BookDaoImpl implements BookDaoI{
@Override
public void addBook(Book b) {
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		                               
		String sql="insert into book values(?,?)";
		         PreparedStatement ps    =con.prepareStatement(sql);
		         
		         ps.setInt(1,b.getBookId());
		         ps.setString(2, b.getBookName());
		        
		         int id=ps.executeUpdate();
		System.out.println(id);
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

@Override
	public void viewBooks() {

	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","root");
		
		String sql="select * from book";
		
		 PreparedStatement  ps=con.prepareStatement(sql);
		
		// ps.setString(1, "abc");
		 
		             ResultSet rs =  ps.executeQuery();
		             while(rs.next()) {
		            	 System.out.println(rs.getInt(1));
		            	 System.out.println(rs.getString(2));
		             }
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
}
