package com.infy.bookmanagmentapp.app.client;

import java.util.Scanner;

import com.infy.bookmanagmentapp.app.model.Book;
import com.infy.bookmanagmentapp.app.service.BookServiceI;
import com.infy.bookmanagmentapp.app.service.BookServiceImpl;

public class BookController {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		BookServiceI bsi=new BookServiceImpl();
		 while(true) {
			 System.out.println("***********MENU***********");
			 System.out.println("1. Add BOOK");
			 System.out.println("2. View BOOK");
			 System.out.println("3. Update BOOK");
			 System.out.println("4. delete BOOK");
			 System.out.println("5. SEARCH BOOK");
			 System.out.println("6. EXIT");
			 
			 System.out.println("Select ANYONE");
			 int ch=sc.nextInt();
			 
			 switch (ch) {
			case 1:
				Book b=new Book();
			System.out.println("Enter Book ID");
			b.setBookId(sc.nextInt());
			System.out.println("Enter Book Name");
			b.setBookName(sc.next());
			bsi.addBook(b);
				break;
	         case 2:
				bsi.viewBooks();
				break;
	         case 3:
	 			
	 			break;
	          case 4:
	 			
	 			break;
	          case 5:
	  			
	  			break;
	           case 6:
	  			System.exit(0);
	  			break;
			default:
				break;
			}
		 }
		
	}

}
