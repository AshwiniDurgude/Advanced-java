package com.infy.bookmanagmentapp.app.service;

import com.infy.bookmanagmentapp.app.model.Book;

public interface BookServiceI {
public void addBook(Book b);
public void viewBooks();
}
