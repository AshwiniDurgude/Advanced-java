package com.infy.bookmanagmentapp.app.dao;

import com.infy.bookmanagmentapp.app.model.Book;

public interface BookDaoI {
	public void addBook(Book b) ;
	public void viewBooks();
}
